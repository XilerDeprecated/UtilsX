.. image:: https://prototype.xiler.net/assets/logo-128x.png
    :alt: Xiler Icon

UtilsX
================================================

The public Xiler Python utility library
***************************************

Currently WIP
